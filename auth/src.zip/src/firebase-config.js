import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDPtfSOiBuZx9JLJ_Bs3F5YxSmp6zRjVxQ",
  authDomain: "authentication-1-49cc6.firebaseapp.com",
  projectId: "authentication-1-49cc6",
  storageBucket: "authentication-1-49cc6.appspot.com",
  messagingSenderId: "1066517433863",
  appId: "1:1066517433863:web:ba55b44da837e10e68e4a2",
  measurementId: "G-22FP5PHT1F",

};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
